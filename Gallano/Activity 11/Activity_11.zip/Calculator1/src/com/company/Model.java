package com.company;

public class
Model {
    public static int addNumbers(int num1, int num2) {
        return num1 + num2;
    }
    public static int subNumbers(int num1, int num2) {
        return num1 - num2;
    }
    public static int multiplyNumbers(int num1, int num2) {
        return num1 * num2;
    }
    public static int divideNumbers(int num1, int num2) {
        return num1 / num2;
    }
    public static int percentNumbers(int num1, int num2) {
        return num1 % num2;
    }
}
